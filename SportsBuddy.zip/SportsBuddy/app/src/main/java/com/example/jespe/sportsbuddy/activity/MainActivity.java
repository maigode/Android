package com.example.jespe.sportsbuddy.activity;

import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;

import android.widget.TextView;
import android.view.View;

import com.example.jespe.sportsbuddy.R;
import com.example.jespe.sportsbuddy.fragment.ActivitiesMapFragment;
import com.example.jespe.sportsbuddy.fragment.AddActivityFragment;
import com.example.jespe.sportsbuddy.fragment.ProfileFragment;

public class MainActivity extends AppCompatActivity {

    private TextView textActivities;
    private TextView textAddActivity;
    private TextView textProfile;
    private ProfileFragment profileFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNavigationView = (BottomNavigationView)
                findViewById(R.id.bottom_navigation);

        bottomNavigationView.setOnNavigationItemSelectedListener(
                new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item){
                        FragmentTransaction transaction;
                        switch (item.getItemId()) {
                            case R.id.action_activities:
                                ActivitiesMapFragment activitiesMapFragment = new ActivitiesMapFragment();
                                transaction =  getFragmentManager().beginTransaction();
                                transaction.replace(R.id.frag_container, activitiesMapFragment).commit();
                                break;
                            case R.id.action_addActivity:
                                AddActivityFragment addActivityFragment = new AddActivityFragment();
                                transaction =  getFragmentManager().beginTransaction();
                                transaction.replace(R.id.frag_container, addActivityFragment).commit();
                                break;
                            case R.id.action_profile:
                                ProfileFragment profileFragment = new ProfileFragment();
                                transaction =  getFragmentManager().beginTransaction();
                                transaction.replace(R.id.frag_container, profileFragment).commit();
                                break;
                        }
                        return false;
                    }
                });
    }
}